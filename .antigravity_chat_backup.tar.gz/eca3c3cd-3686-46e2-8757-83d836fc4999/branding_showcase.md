# Mantis Mobile Forensics — Official Visual Identity & Brand Guide

![Mantis Mobile Forensics Official Emblem](/home/kali/.gemini/antigravity/brain/eca3c3cd-3686-46e2-8757-83d836fc4999/mantis_logo_1791987222775.jpg)

## Brand Concept & Design Rationale

The new visual identity for **Mantis Mobile Forensics (MMF)** was crafted to reflect the precision, speed, and analytical vigilance of digital forensics and incident response (DFIR):

- **The Robotic Praying Mantis**: Represents lethal surgical precision, rapid acquisition, and predatory vigilance in uncovering hidden, deleted, and obfuscated mobile evidence.
- **The Defense Shield**: Symbolizes evidence vault integrity, chain-of-custody defense, and strict preservation of digital proof.
- **Cyber Circuit Traces**: Illustrates hardware-level extraction, forensic chip-off / JTAG / ADB communication, and deep filesystem navigation.
- **Neon Cyan & Emerald Palette**: High-contrast, tactical cyber-aesthetic tailored specifically for dark-mode Kali Linux forensic workstations.

---

## Assets Configured & Set Across the System

| Target Location | Asset Format | Resolution / Purpose |
|---|---|---|
| `assets/icon.png` | PNG (24-bit with alpha) | 512x512 Master Desktop Icon |
| `assets/mantis.png` | PNG (24-bit with alpha) | 256x256 System & Menu Icon |
| `apps/web/public/logo.png` | PNG | React & Vite Web Application Logo |
| `apps/web/dist/logo.png` | PNG | Production Standalone Electron Asset |
| `~/.local/share/pixmaps/mantis.png` | PNG | Kali Linux Application Menu Icon |
| `~/.local/share/icons/hicolor/256x256/apps/mantis.png` | PNG | FreeDesktop XDG Icon Cache |
| `~/.local/share/icons/hicolor/scalable/apps/mantis.png` | PNG | Window Manager & Alt-Tab Task Switcher |
| `~/.local/share/applications/mantis-mobile-forensics.desktop` | Desktop Entry | Integrated Launcher (`Icon=mantis`) |
| `mantis-mobile-forensics_1.0.0_amd64.deb` | Debian Archive | Pre-packaged distributable installer |

---

## UI Integration Highlights

1. **Sidebar Navigation Header**:
   The new high-tech emblem is displayed at the top of the sidebar with an emerald-cyan ring and hover state.
2. **TopBar Workstation Header**:
   Positioned next to the active forensic case badge and case title.
3. **Electron Window Taskbar & Title**:
   Configured in `apps/desktop/main.js` so the application window, taskbar dock, and Alt-Tab window switcher display the official icon.
4. **Kali Application Menu**:
   Listed under `Applications -> Forensics -> Mantis Mobile Forensics` with the native launcher icon.
