import os
import shutil

zshrc_path = os.path.expanduser("~/.zshrc")
bashrc_path = os.path.expanduser("~/.bashrc")

override_zsh = """
# Custom prompt override for NullX-D㉿Rakib
if [[ -n "$PROMPT" ]]; then
    PROMPT="${PROMPT//\\%n㉿\\%m/NullX-D㉿Rakib}"
    PROMPT="${PROMPT//\\%n@\\%m/NullX-D@Rakib}"
fi
"""

override_bash = """
# Custom prompt override for NullX-D㉿Rakib
if [ -n "$PS1" ]; then
    PS1="${PS1//\\\\u㉿\\\\h/NullX-D㉿Rakib}"
    PS1="${PS1//\\\\u@\\\\h/NullX-D@Rakib}"
fi
"""

def update_file(path, override_text, marker="NullX-D㉿Rakib"):
    if not os.path.exists(path):
        print(f"File not found: {path}")
        return False
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()
    if marker in content:
        print(f"Already configured in: {path}")
        return True
    
    # Create backup
    backup_path = f"{path}.bak"
    shutil.copy2(path, backup_path)
    print(f"Backup created at: {backup_path}")
    
    with open(path, "a", encoding="utf-8") as f:
        f.write(override_text)
    print(f"Successfully updated: {path}")
    return True

print("Applying prompt customization...")
zsh_updated = update_file(zshrc_path, override_zsh)
bash_updated = update_file(bashrc_path, override_bash)
print("Done!")
